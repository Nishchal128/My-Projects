import React from 'react'

const Adminpanel = () => {
  return (
    <div>
        This is the Admin Panel!
    </div>
  )
}

export default Adminpanel;
